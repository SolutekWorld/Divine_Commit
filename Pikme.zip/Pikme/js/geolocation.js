/* Javascript file to find the location of a user */

//var x = document.getElementById("pikMeTaxi");
//var y = document.getElementById()

function getLocation(){
	if(navigator.geolocation){
		navigator.geolocation.getCurrentPosition(showPosition, showError);
	}else{
		map_url.innerHTML ="Geolocation is not supported by this browser/device";
	}
}

function showPostion(position){
	var latlon = position.coords.latitude + "," + position.coords.longitude;
	
	var map_url ="http://maps.googleapis.com/maps/api/staticmap>center" + 
					latlon +"&zoom=14&size=400x300&sensor=false";

	document.getElementById("map_container").innerHTML ="<img src='"+map_url+"'>";
}

function showError(error){
	switch(error.code){
		case error.PERMISSION_DENIED:
			map_url.innerHTML ="User denied the request for Geolocation"
			break;
		case error.POSITION_UNAVAILABLE:
			map_url.innerHTML ="Location information unavailable."
			break;
		case error.TIMEOUT:
			map_url.innerHTML ="The request to get user location timed out."
			break;
		case error.UNKWOWN_ERROR:
			map_url.innerHTML ="An unknown error occured."
			break;
	}
}

//function to watch user position 

function watchUserPos(){
	if(navigator.geolocation){
		var watcher = navigator.geolocation.watchPosition(showPosition);
	}else {
		var watcher ="Unable to watch user position ";
	}
}

//Main 
//start watchPosition
watchUserPos();
//start getLocation
getLocation();
